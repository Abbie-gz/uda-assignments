Reference:
1. https://classroom.udacity.com/
   Nanodegree Program
2. https://pandas.pydata.org